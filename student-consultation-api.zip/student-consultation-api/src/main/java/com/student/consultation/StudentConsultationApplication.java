package com.student.consultation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentConsultationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentConsultationApplication.class, args);
	}

}
